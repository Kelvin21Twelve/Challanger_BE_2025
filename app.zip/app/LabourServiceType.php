<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LabourServiceType extends Model {

    protected $fillable = [
        'type'
    ];

}
